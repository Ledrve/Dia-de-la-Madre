document.addEventListener('DOMContentLoaded', function() {
    const paraButton = document.getElementById('paraButton');
    const paperSlip = document.getElementById('paperSlip');

    if (paraButton && paperSlip) {
        paraButton.addEventListener('click', function() {
            // Si el papelito ya está visible, lo ocultamos (opcional, o podrías querer que solo se abra)
            if (paperSlip.classList.contains('visible')) {
                // Podrías decidir no hacer nada si ya está abierto, o cerrarlo:
                // paperSlip.classList.remove('visible');
            } else {
                paperSlip.classList.add('visible');
                // Opcional: Desplazar la vista hacia el papelito si la página es larga
                // setTimeout(() => { // Da tiempo a que se haga visible antes de hacer scroll
                //     paperSlip.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                // }, 100); // Un pequeño delay
            }
        });
    } else {
        console.error("No se encontraron los elementos paraButton o paperSlip.");
    }
});
